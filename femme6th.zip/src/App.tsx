import React from "react";

function App() {
  return (
    <h1 style={{ textAlign: "center", marginTop: "2rem" }}>
      🚀 Mi Web funcionando en Vercel con Vite + React + TSX
    </h1>
  );
}

export default App;